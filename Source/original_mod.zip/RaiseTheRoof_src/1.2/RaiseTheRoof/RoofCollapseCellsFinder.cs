using Verse;
using System.Collections.Generic;

namespace RaiseTheRoof
{
	public static class RoofCollapseCellsFinder
	{
		private static HashSet<IntVec3> visitedCells = new HashSet<IntVec3>();
        private static List<IntVec3> roofsCollapsingBecauseTooFar = new List<IntVec3>();

        public static void CheckCollapseFlyingRoofs(List<IntVec3> nearCells, Map map, bool removalMode = false, bool canRemoveThickRoof = false)
        {
            visitedCells.Clear();
            for (int i = 0; i < nearCells.Count; i++)
            {
                CheckCollapseFlyingRoofAtAndAdjInternal(nearCells[i], map, removalMode, canRemoveThickRoof);
            }
            visitedCells.Clear();
        }
        public static void CheckCollapseFlyingRoofsRect(CellRect nearRect, Map map, bool removalMode = false, bool canRemoveThickRoof = false)
        {
            RoofCollapseCellsFinder.visitedCells.Clear();
            using (CellRect.Enumerator enumerator = nearRect.GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    CheckCollapseFlyingRoofAtAndAdjInternal(enumerator.Current, map, removalMode, canRemoveThickRoof);
                }
            }
            visitedCells.Clear();
        }
        private static bool CheckCollapseFlyingRoofAtAndAdjInternal(IntVec3 root, Map map, bool removalMode, bool canRemoveThickRoof)
		{
			RoofCollapseBuffer roofCollapseBuffer = map.roofCollapseBuffer;
			if (removalMode && roofCollapseBuffer.CellsMarkedToCollapse.Count > 0)
			{
				map.roofCollapseBufferResolver.CollapseRoofsMarkedToCollapse();
			}
			for (int i = 0; i < 5; i++)
			{
				IntVec3 intVec = root + GenAdj.CardinalDirectionsAndInside[i];
				if (intVec.InBounds(map))
				{
					if (intVec.Roofed(map))
					{
                        if (!visitedCells.Contains(intVec))
						{
                            if (!roofCollapseBuffer.IsMarkedToCollapse(intVec))
							{
                                if (!ConnectsToRoofHolder(intVec, map, visitedCells))
								{
                                    map.floodFiller.FloodFill(intVec, (IntVec3 x) => x.Roofed(map), delegate(IntVec3 x)
									{
										roofCollapseBuffer.MarkToCollapse(x);
									}, int.MaxValue, false, null);
									if (removalMode)
									{
										List<IntVec3> cellsMarkedToCollapse = roofCollapseBuffer.CellsMarkedToCollapse;
										for (int j = cellsMarkedToCollapse.Count - 1; j >= 0; j--)
										{
                                            RoofDef roofDef = map.roofGrid.RoofAt(cellsMarkedToCollapse[j]);
											if (roofDef != null && (canRemoveThickRoof || !rockThickRoof(roofDef)))
											{
                                                Thing thing = RTRUtils.RemoveRoofExists(cellsMarkedToCollapse[j], map);
                                                if (thing != null)
                                                {
                                                    thing.Kill();
                                                }
												map.roofGrid.SetRoof(cellsMarkedToCollapse[j], null);
												cellsMarkedToCollapse.RemoveAt(j);
											}
                                        }
									}
								}
							}
						}
					}
				}
			}
			return false;
		}
        public static bool rockThickRoof(RoofDef def)
        {
            if (def == RimWorld.RoofDefOf.RoofRockThick)
            {
                return true;
            }
            return false;
        }
        public static bool ConnectsToRoofHolder(IntVec3 c, Map map, HashSet<IntVec3> visitedCells)
		{
			bool connected = false;
			map.floodFiller.FloodFill(c, (IntVec3 x) => x.Roofed(map) && !connected, delegate(IntVec3 x)
			{
				if (visitedCells.Contains(x))
				{
					connected = true;
					return;
				}
				visitedCells.Add(x);
				for (int i = 0; i < 5; i++)
				{
					IntVec3 c2 = x + GenAdj.CardinalDirectionsAndInside[i];
					if (c2.InBounds(map))
					{
						Building edifice = c2.GetEdifice(map);
						if (edifice != null && edifice.def.holdsRoof)
						{
							connected = true;
							break;
						}
					}
				}
			}, int.MaxValue, false, null);
			return connected;
		}
        public static void ProcessRoofHolderDespawned(CellRect rect, IntVec3 position, Map map, bool removalMode = false, bool canRemoveThickRoof = false)
        {
            CheckCollapseFlyingRoofsRect(rect, map, removalMode, canRemoveThickRoof);
            RoofGrid roofGrid = map.roofGrid;
            roofsCollapsingBecauseTooFar.Clear();
            for (int i = 0; i < RoofCollapseUtility.RoofSupportRadialCellsCount; i++)
            {
                IntVec3 intVec = position + GenRadial.RadialPattern[i];
                if (intVec.InBounds(map) && roofGrid.Roofed(intVec.x, intVec.z) && !map.roofCollapseBuffer.IsMarkedToCollapse(intVec) && !RoofCollapseUtility.WithinRangeOfRoofHolder(intVec, map, false))
                {
                    if (removalMode && (canRemoveThickRoof || intVec.GetRoof(map).VanishOnCollapse))
                    {
                        Thing thing = RTRUtils.RemoveRoofExists(intVec, map);
                        if (thing != null)
                        {
                            thing.Kill();
                        }
                        map.roofGrid.SetRoof(intVec, null);
                    }
                    else
                    {
                        map.roofCollapseBuffer.MarkToCollapse(intVec);
                    }
                    roofsCollapsingBecauseTooFar.Add(intVec);
                }
            }
            CheckCollapseFlyingRoofs(roofsCollapsingBecauseTooFar, map, removalMode, canRemoveThickRoof);
            roofsCollapsingBecauseTooFar.Clear();
        }
    }
}
