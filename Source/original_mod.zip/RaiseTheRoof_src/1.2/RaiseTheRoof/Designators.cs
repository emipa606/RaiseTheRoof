using RimWorld;
using Verse;
using System.Collections.Generic;

namespace RaiseTheRoof
{
    public class Designator_BuildSteelRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_BuildSteelRoof() : base(ThingDefOf.RTR_SteelRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }

        public override string Label
        {
            get
            {
                return "DesignatorAreaBuildSteelRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaBuildSteelRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef.isThickRoof)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                Map.roofGrid.SetRoof(c, RoofDefOf.RTR_RoofSteel);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }

        public override bool ShowWarningForCell(IntVec3 c)
        {
            foreach (Thing current in Map.thingGrid.ThingsAt(c))
            {
                if (current.def.plant != null && current.def.plant.interferesWithRoof)
                {
                    Messages.Message("MessageRoofIncompatibleWithPlant".Translate(current), MessageTypeDefOf.CautionInput, false);
                    return true;
                }
            }
            return false;
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }
    public class Designator_RemoveSteelRoof : Designator_Build
    {
		public override int DraggableDimensions
		{
			get
			{
				return 2;
			}
		}

		public override bool DragDrawMeasurements
		{
			get
			{
				return true;
			}
		}
        public Designator_RemoveSteelRoof() : base(ThingDefOf.RTR_RemoveSteelRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }
        public override string Label
        {
            get
            {
                return "DesignatorAreaRemoveSteelRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaRemoveSteelRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
		{
			if (!c.InBounds(Map))
			{
				return false;
			}
			if (c.Fogged(Map))
			{
				return false;
			}
			RoofDef roofDef = Map.roofGrid.RoofAt(c);
			if (roofDef != null && roofDef != RoofDefOf.RTR_RoofSteel)
			{
				return false;
			}
            if (roofDef == null)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
		}

		public override void DesignateSingleCell(IntVec3 c)
		{
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                RoofDef def = Map.roofGrid.RoofAt(c);
                Map.roofGrid.SetRoof(c, null);
                RTRUtils.RemoveRoof(c, Map, def);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }
		public override void SelectedUpdate()
		{
			GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }

    public class Designator_BuildSolarRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_BuildSolarRoof() : base(ThingDefOf.RTR_SolarRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }

        public override string Label
        {
            get
            {
                return "DesignatorAreaBuildSolarRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaBuildSolarRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef.isThickRoof)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                Map.roofGrid.SetRoof(c, RoofDefOf.RTR_RoofSolar);
                ThingDef thingDef = RTRUtils.SelectPowerCell(RoofDefOf.RTR_RoofSolar);
                if (thingDef != null)
                {
                    RTRUtils.InstallSolarCell(thingDef, c, Map);
                }
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }

        public override bool ShowWarningForCell(IntVec3 c)
        {
            foreach (Thing current in Map.thingGrid.ThingsAt(c))
            {
                if (current.def.plant != null && current.def.plant.interferesWithRoof)
                {
                    Messages.Message("MessageRoofIncompatibleWithPlant".Translate(current), MessageTypeDefOf.CautionInput, false);
                    return true;
                }
            }
            return false;
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }
    public class Designator_RemoveSolarRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_RemoveSolarRoof() : base(ThingDefOf.RTR_RemoveSolarRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }
        public override string Label
        {
            get
            {
                return "DesignatorAreaRemoveSolarRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaRemoveSolarRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef != RoofDefOf.RTR_RoofSolar)
            {
                return false;
            }
            if (roofDef == null)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                RoofDef def = Map.roofGrid.RoofAt(c);
                Map.roofGrid.SetRoof(c, null);
                RTRUtils.RemoveRoof(c, Map, def);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }

    public class Designator_BuildTransparentRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_BuildTransparentRoof() : base(ThingDefOf.RTR_TransparentRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }

        public override string Label
        {
            get
            {
                return "DesignatorAreaBuildTransparentRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaBuildTransparentRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef.isThickRoof)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                Map.roofGrid.SetRoof(c, RoofDefOf.RTR_RoofTransparent);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }

        public override bool ShowWarningForCell(IntVec3 c)
        {
            foreach (Thing current in Map.thingGrid.ThingsAt(c))
            {
                if (current.def.plant != null && current.def.plant.interferesWithRoof)
                {
                    Messages.Message("MessageRoofIncompatibleWithPlant".Translate(current), MessageTypeDefOf.CautionInput, false);
                    return true;
                }
            }
            return false;
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }
    public class Designator_RemoveTransparentRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_RemoveTransparentRoof() : base(ThingDefOf.RTR_RemoveTransparentRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }
        public override string Label
        {
            get
            {
                return "DesignatorAreaRemoveTransparentRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaRemoveTransparentRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef != RoofDefOf.RTR_RoofTransparent)
            {
                return false;
            }
            if (roofDef == null)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                RoofDef def = Map.roofGrid.RoofAt(c);
                Map.roofGrid.SetRoof(c, null);
                RTRUtils.RemoveRoof(c, Map, def);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }

    public class Designator_BuildTransparentSolarRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_BuildTransparentSolarRoof() : base(ThingDefOf.RTR_TransparentSolarRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }

        public override string Label
        {
            get
            {
                return "DesignatorAreaBuildTransparentSolarRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaBuildTransparentSolarRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef.isThickRoof)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                Map.roofGrid.SetRoof(c, RoofDefOf.RTR_RoofTransparentSolar);
                ThingDef thingDef = RTRUtils.SelectPowerCell(RoofDefOf.RTR_RoofTransparentSolar);
                if (thingDef != null)
                {
                    RTRUtils.InstallSolarCell(thingDef, c, Map);
                }
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }

        public override bool ShowWarningForCell(IntVec3 c)
        {
            foreach (Thing current in Map.thingGrid.ThingsAt(c))
            {
                if (current.def.plant != null && current.def.plant.interferesWithRoof)
                {
                    Messages.Message("MessageRoofIncompatibleWithPlant".Translate(current), MessageTypeDefOf.CautionInput, false);
                    return true;
                }
            }
            return false;
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }
    public class Designator_RemoveTransparentSolarRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_RemoveTransparentSolarRoof() : base(ThingDefOf.RTR_RemoveTransparentSolarRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }
        public override string Label
        {
            get
            {
                return "DesignatorAreaRemoveTransparentSolarRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaRemoveTransparentSolarRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef != RoofDefOf.RTR_RoofTransparentSolar)
            {
                return false;
            }
            if (roofDef == null)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                RoofDef def = Map.roofGrid.RoofAt(c);
                Map.roofGrid.SetRoof(c, null);
                RTRUtils.RemoveRoof(c, Map, def);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }

    public class Designator_RemoveMountainousRoof : Designator_Build
    {
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }

        public override bool DragDrawMeasurements
        {
            get
            {
                return true;
            }
        }
        public Designator_RemoveMountainousRoof() : base(ThingDefOf.RTR_RemoveMountainousRoof) { }
        public override BuildableDef PlacingDef { get => entDef; }
        public override string Label
        {
            get
            {
                return "DesignatorAreaRemoveMountainousRoofExpand".Translate().CapitalizeFirst();
            }
        }
        public override string Desc
        {
            get
            {
                return "DesignatorAreaRemoveMountainousRoofExpandDesc".Translate().CapitalizeFirst();
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map))
            {
                return false;
            }
            if (c.Fogged(Map))
            {
                return false;
            }
            RoofDef roofDef = Map.roofGrid.RoofAt(c);
            if (roofDef != null && roofDef != RimWorld.RoofDefOf.RoofRockThick)
            {
                return false;
            }
            if (roofDef == null)
            {
                return false;
            }
            if (RTRUtils.RoofThingDefExists(Map.thingGrid.ThingsListAt(c)))
            {
                return false;
            }
            return true;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            if (DebugSettings.godMode)
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                RoofDef def = Map.roofGrid.RoofAt(c);
                Map.roofGrid.SetRoof(c, null);
                RTRUtils.RemoveRoof(c, Map, def);
            }
            else
            {
                Map.areaManager.BuildRoof[c] = false;
                Map.areaManager.NoRoof[c] = false;
                GenConstruct.PlaceBlueprintForBuild(PlacingDef, c, Map, placingRot, Faction.OfPlayer, null);
            }
        }
        public override void SelectedUpdate()
        {
            GenUI.RenderMouseoverBracket();
            Map.areaManager.BuildRoof.MarkForDraw();
            Map.areaManager.NoRoof.MarkForDraw();
            Map.roofGrid.Drawer.MarkForDraw();
        }
    }
}
