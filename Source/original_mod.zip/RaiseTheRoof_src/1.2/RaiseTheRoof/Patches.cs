using HarmonyLib;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using Verse;
using Verse.AI;
using RimWorld;
using UnityEngine;
using UnityEngine.Events;

namespace RaiseTheRoof
{
    [StaticConstructorOnStartup]
    static class Patches
    {
        public const BindingFlags allFlags = BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.GetField | BindingFlags.GetProperty | BindingFlags.SetProperty;
        static Patches()
        {
            var harmony = new Harmony("raisetheroof.harmony");
            CreateFrameAndBlueprintDefs.Begin();
            harmony.PatchAll();
        }
        static class CreateFrameAndBlueprintDefs
        {
            public static MethodInfo MI_NewBlueprintDef_Thing = typeof(ThingDefGenerator_Buildings).GetMethod("NewBlueprintDef_Thing", allFlags);
            public static MethodInfo MI_NewFrameDef_Thing = typeof(ThingDefGenerator_Buildings).GetMethod("NewFrameDef_Thing", allFlags);
            public static MethodInfo MI_GiveShortHash = typeof(ShortHashGiver).GetMethod("GiveShortHash", allFlags);
            static ThingDef NewBlueprintDef_Thing(ThingDef def, bool isInstallBlueprint, ThingDef normalBlueprint = null)
            {
                return (ThingDef)MI_NewBlueprintDef_Thing.Invoke(null, new object[] { def, isInstallBlueprint, normalBlueprint });
            }
            static ThingDef NewFrameDef_Thing(ThingDef def)
            {
                return (ThingDef)MI_NewFrameDef_Thing.Invoke(null, new object[] { def });
            }
            static void GiveShortHash(Def def, Type defType)
            {
                MI_GiveShortHash.Invoke(null, new object[] { def, defType });
            }
            public static void Begin()
            {
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_SteelRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_RemoveSteelRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_SolarRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_RemoveSolarRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_TransparentRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_RemoveTransparentRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_TransparentSolarRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_RemoveTransparentSolarRoof);
                CreateBlueprintAndFrameDefs(ThingDefOf.RTR_RemoveMountainousRoof);
            }
            static void CreateBlueprintAndFrameDefs(ThingDef thingDef)
            {
                ThingDef def = thingDef;
                ThingDef bpDef = NewBlueprintDef_Thing(def, false, null);
                GiveShortHash(bpDef, typeof(ThingDef));
                DefDatabase<ThingDef>.Add(bpDef);

                def = thingDef;
                ThingDef fDef = NewFrameDef_Thing(def);
                GiveShortHash(fDef, typeof(ThingDef));
                DefDatabase<ThingDef>.Add(fDef);
            }
        }
        [HarmonyPatch(typeof(SectionLayer_LightingOverlay))]
        [HarmonyPatch("Regenerate")]
        static class Patch_SectionLayer_LightingOverlay_Regenerate
        {
            static PropertyInfo PI_Map = typeof(SectionLayer).GetProperty("Map", allFlags);
            static FieldInfo FI_sectRect = typeof(SectionLayer_LightingOverlay).GetField("sectRect", allFlags);
            static FieldInfo FI_firstCenterInd = typeof(SectionLayer_LightingOverlay).GetField("firstCenterInd", allFlags);
            static FieldInfo FI_glowGrid = typeof(SectionLayer_LightingOverlay).GetField("glowGrid", allFlags);
            static MethodInfo MI_MakeBaseGeometry = typeof(SectionLayer_LightingOverlay).GetMethod("MakeBaseGeometry", allFlags);

            static Map Map(SectionLayer_LightingOverlay instance)
            {
                return (Map)PI_Map.GetValue(instance, null);
            }
            static CellRect sectRect(SectionLayer_LightingOverlay instance)
            {
                return (CellRect)FI_sectRect.GetValue(instance);
            }
            static int firstCenterInd(SectionLayer_LightingOverlay instance)
            {
                return (int)FI_firstCenterInd.GetValue(instance);
            }
            static Color32[] glowGrid(SectionLayer_LightingOverlay instance)
            {
                return (Color32[])FI_glowGrid.GetValue(instance);
            }
            static void MakeBaseGeometry(SectionLayer_LightingOverlay instance, LayerSubMesh sm)
            {
                MI_MakeBaseGeometry.Invoke(instance, new object[] { sm });
            }
            static void CalculateVertexIndices(SectionLayer_LightingOverlay instance, int worldX, int worldZ, out int botLeft, out int topLeft, out int topRight, out int botRight, out int center)
            {
                int num = worldX - sectRect(instance).minX;
                int num2 = worldZ - sectRect(instance).minZ;
                botLeft = num2 * (sectRect(instance).Width + 1) + num;
                topLeft = (num2 + 1) * (sectRect(instance).Width + 1) + num;
                topRight = (num2 + 1) * (sectRect(instance).Width + 1) + (num + 1);
                botRight = num2 * (sectRect(instance).Width + 1) + (num + 1);
                center = firstCenterInd(instance) + (num2 * sectRect(instance).Width + num);
            }

            static bool Prefix(SectionLayer_LightingOverlay __instance)
            {
                LayerSubMesh subMesh = __instance.GetSubMesh(MatBases.LightOverlay);
                if (subMesh.verts.Count == 0)
                {
                    MakeBaseGeometry(__instance, subMesh);
                }
                Color32[] array = new Color32[subMesh.verts.Count];
                int maxX = sectRect(__instance).maxX;
                int maxZ = sectRect(__instance).maxZ;
                int width = sectRect(__instance).Width;
                Map map = Map(__instance);
                int x = map.Size.x;
                Thing[] innerArray = map.edificeGrid.InnerArray;
                Thing[] array2 = innerArray;
                int num = array2.Length;
                RoofGrid roofGrid = map.roofGrid;
                CellIndices cellIndices = map.cellIndices;
                int num2;
                int num3;
                int num4;
                int num5;
                int num6;
                CalculateVertexIndices(__instance, sectRect(__instance).minX, sectRect(__instance).minZ, out num2, out num3, out num4, out num5, out num6);
                int num7 = cellIndices.CellToIndex(new IntVec3(sectRect(__instance).minX, 0, sectRect(__instance).minZ));
                int[] intarray = new int[4];
                intarray[0] = -map.Size.x - 1;
                intarray[1] = -map.Size.x;
                intarray[2] = -1;
                int[] array3 = intarray;
                int[] intarray2 = new int[4];
                intarray2[0] = -1;
                intarray2[1] = -1;
                int[] array4 = intarray2;
                for (int i = sectRect(__instance).minZ; i <= maxZ + 1; i++)
                {
                    int num8 = num7 / x;
                    int j = sectRect(__instance).minX;
                    while (j <= maxX + 1)
                    {
                        ColorInt colorInt = new ColorInt(0, 0, 0, 0);
                        int num9 = 0;
                        bool flag = false;
                        for (int k = 0; k < 4; k++)
                        {
                            int num10 = num7 + array3[k];
                            if (num10 >= 0 && num10 < num && num10 / x == num8 + array4[k])
                            {
                                Thing thing = array2[num10];
                                RoofDef roofDef = roofGrid.RoofAt(num10);
                                if (roofDef != null)
                                {
                                    if (roofDef != RoofDefOf.RTR_RoofTransparent && roofDef != RoofDefOf.RTR_RoofTransparentSolar)
                                    {
                                        if ((roofDef == RimWorld.RoofDefOf.RoofRockThick) || thing == null || !thing.def.holdsRoof || thing.def.altitudeLayer == AltitudeLayer.DoorMoveable)
                                        {
                                            flag = true;
                                        }
                                    }
                                }
                                if (thing == null || !thing.def.blockLight)
                                {
                                    colorInt += glowGrid(__instance)[num10];
                                    num9++;
                                }
                            }
                        }
                        if (num9 > 0)
                        {
                            array[num2] = (colorInt / num9).ToColor32;
                        }
                        else
                        {
                            array[num2] = new Color32(0, 0, 0, 0);
                        }
                        if (flag && array[num2].a < 100)
                        {
                            array[num2].a = 100;
                        }
                        j++;
                        num2++;
                        num7++;
                    }
                    int num11 = maxX + 2 - sectRect(__instance).minX;
                    num2 -= num11;
                    num7 -= num11;
                    num2 += width + 1;
                    num7 += map.Size.x;
                }
                int num12;
                int num13;
                int num14;
                int num15;
                int num16;
                CalculateVertexIndices(__instance, sectRect(__instance).minX, sectRect(__instance).minZ, out num12, out num13, out num14, out num15, out num16);
                int num17 = cellIndices.CellToIndex(sectRect(__instance).minX, sectRect(__instance).minZ);
                for (int l = sectRect(__instance).minZ; l <= maxZ; l++)
                {
                    int m = sectRect(__instance).minX;
                    while (m <= maxX)
                    {
                        ColorInt colorInt2 = default(ColorInt) + array[num12];
                        colorInt2 += array[num12 + 1];
                        colorInt2 += array[num12 + width + 1];
                        colorInt2 += array[num12 + width + 2];
                        array[num16] = new Color32((byte)(colorInt2.r / 4), (byte)(colorInt2.g / 4), (byte)(colorInt2.b / 4), (byte)(colorInt2.a / 4));
                        if (roofGrid.RoofAt(num17) != RoofDefOf.RTR_RoofTransparent && roofGrid.RoofAt(num17) != RoofDefOf.RTR_RoofTransparentSolar)
                        {
                            if (array[num16].a < 100 && roofGrid.Roofed(num17))
                            {
                                Thing thing2 = array2[num17];
                                if (thing2 == null || !thing2.def.holdsRoof)
                                {
                                    array[num16].a = 100;
                                }
                            }
                        }
                        m++;
                        num12++;
                        num16++;
                        num17++;
                    }
                    num12++;
                    num17 -= width;
                    num17 += map.Size.x;
                }
                subMesh.mesh.colors32 = array;

                return false;
            }
        }
        [HarmonyPatch(typeof(RoofGrid))]
        [HarmonyPatch("Color", MethodType.Getter)]
        static class Patch_RoofGrid_Color
        {
            static bool Prefix(ref Color __result)
            {
                __result = Color.white;
                return false;
            }
        }
        [HarmonyPatch(typeof(RoofGrid))]
        [HarmonyPatch("GetCellExtraColor")]
        static class Patch_RoofGrid_GetCellExtraColor
        {
            static FieldInfo FI_wantDraw = typeof(CellBoolDrawer).GetField("wantDraw", allFlags);
            static FieldInfo FI_drawer = typeof(Area).GetField("drawer", allFlags);
            static FieldInfo FI_map = typeof(RoofGrid).GetField("map", allFlags);
            static FieldInfo FI_roofGrid = typeof(RoofGrid).GetField("roofGrid", allFlags);
            static bool wantDraw(CellBoolDrawer instance)
            {
                return (bool)FI_wantDraw.GetValue(instance);
            }
            static CellBoolDrawer drawer(Area instance)
            {
                return (CellBoolDrawer)FI_drawer.GetValue(instance);
            }
            static Map map(RoofGrid instance)
            {
                return (Map)FI_map.GetValue(instance);
            }
            static RoofDef[] roofGrid(RoofGrid instance)
            {
                return (RoofDef[])FI_roofGrid.GetValue(instance);
            }
            public static Color GetCellExtraColor(RoofGrid instance, int index)
            {
                if (RimWorld.RoofDefOf.RoofRockThick != null && roofGrid(instance)[index] == RimWorld.RoofDefOf.RoofRockThick)
                {
                    Color orange = new Color(1.0f, 0.65f, 0f);
                    return orange;
                }
                else if (RimWorld.RoofDefOf.RoofRockThin != null && roofGrid(instance)[index] == RimWorld.RoofDefOf.RoofRockThin)
                {
                    return Color.yellow;
                }
                else if (RimWorld.RoofDefOf.RoofConstructed != null && roofGrid(instance)[index] == RimWorld.RoofDefOf.RoofConstructed)
                {
                    return Color.cyan;
                }
                else if (RoofDefOf.RTR_RoofSteel != null && roofGrid(instance)[index] == RoofDefOf.RTR_RoofSteel)
                {
                    return Color.blue;
                }
                else if (RoofDefOf.RTR_RoofSolar != null && roofGrid(instance)[index] == RoofDefOf.RTR_RoofSolar)
                {
                    Color teal = new Color(0f, 0.42f, 0.33f);
                    return teal;
                }
                else if (RoofDefOf.RTR_RoofTransparent != null && roofGrid(instance)[index] == RoofDefOf.RTR_RoofTransparent)
                {
                    Color pink = new Color(0.93f, 0.51f, 0.93f);
                    return pink;
                }
                else if (RoofDefOf.RTR_RoofTransparentSolar != null && roofGrid(instance)[index] == RoofDefOf.RTR_RoofTransparentSolar)
                {
                    Color purple = new Color(0.49f, 0.15f, 0.80f);
                    return purple;
                }
                return Color.white;
            }
            static bool Prefix(RoofGrid __instance, ref Color __result, int index)
            {
                __result = GetCellExtraColor(__instance, index);
                return false;
            }
        }
        [HarmonyPatch(typeof(Designator_AreaBuildRoof))]
        [HarmonyPatch("CanDesignateCell")]
        static class Patch_Designator_AreaBuildRoof_CanDesignateCell
        {
            public static bool CanDesignateCell(Designator_AreaBuildRoof instance, IntVec3 c)
            {
                if (!c.InBounds(instance.Map))
                {
                    return false;
                }
                if (c.Fogged(instance.Map))
                {
                    return false;
                }
                RoofDef roofDef = instance.Map.roofGrid.RoofAt(c);
                if (roofDef != null)
                {
                    if (roofDef == RimWorld.RoofDefOf.RoofRockThick) return false;
                    if (roofDef == RoofDefOf.RTR_RoofSteel) return false;
                    if (roofDef == RoofDefOf.RTR_RoofSolar) return false;
                    if (roofDef == RoofDefOf.RTR_RoofTransparent) return false;
                    if (roofDef == RoofDefOf.RTR_RoofTransparentSolar) return false;
                }
                if (RTRUtils.RoofThingDefExists(instance.Map.thingGrid.ThingsListAt(c)))
                {
                    return false;
                }
                return true;
            }
            static bool Prefix(Designator_AreaBuildRoof __instance, ref AcceptanceReport __result, IntVec3 c)
            {
                __result = CanDesignateCell(__instance, c);
                return false;
            }
        }
        [HarmonyPatch(typeof(Designator_AreaBuildRoof))]
        [HarmonyPatch("SelectedUpdate")]
        static class Patch_Designator_AreaBuildRoof_SelectedUpdate
        {
            static bool Prefix(ref Designator_AreaBuildRoof __instance)
            {
                GenUI.RenderMouseoverBracket();
                __instance.Map.areaManager.BuildRoof.MarkForDraw();
                __instance.Map.areaManager.NoRoof.MarkForDraw();
                __instance.Map.roofGrid.Drawer.MarkForDraw();
                return false;
            }
        }
        [HarmonyPatch(typeof(Designator_AreaNoRoof))]
        [HarmonyPatch("CanDesignateCell")]
        static class Patch_Designator_AreaNoRoof_CanDesignateCell
        {
            public static bool CanDesignateCell(Designator_AreaNoRoof instance, IntVec3 c)
            {
                if (!c.InBounds(instance.Map))
                {
                    return false;
                }
                if (c.Fogged(instance.Map))
                {
                    return false;
                }
                RoofDef roofDef = instance.Map.roofGrid.RoofAt(c);
                if (roofDef != null)
                {
                    if (roofDef == RimWorld.RoofDefOf.RoofRockThick) return false;
                    if (roofDef == RoofDefOf.RTR_RoofSteel) return false;
                    if (roofDef == RoofDefOf.RTR_RoofSolar) return false;
                    if (roofDef == RoofDefOf.RTR_RoofTransparent) return false;
                    if (roofDef == RoofDefOf.RTR_RoofTransparentSolar) return false;
                }
                if (RTRUtils.RoofThingDefExists(instance.Map.thingGrid.ThingsListAt(c)))
                {
                    return false;
                }
                return true;
            }
            static bool Prefix(Designator_AreaNoRoof __instance, ref AcceptanceReport __result, IntVec3 c)
            {
                __result = CanDesignateCell(__instance, c);
                return false;
            }
        }
        [HarmonyPatch(typeof(Designator_AreaNoRoof))]
        [HarmonyPatch("SelectedUpdate")]
        static class Patch_Designator_AreaNoRoof_SelectedUpdate
        {
            static bool Prefix(ref Designator_AreaNoRoof __instance)
            {
                GenUI.RenderMouseoverBracket();
                __instance.Map.areaManager.NoRoof.MarkForDraw();
                __instance.Map.areaManager.BuildRoof.MarkForDraw();
                __instance.Map.roofGrid.Drawer.MarkForDraw();
                return false;
            }
        }
        [HarmonyPatch(typeof(AutoBuildRoofAreaSetter))]
        [HarmonyPatch("TryGenerateAreaNow")]
        static class Patch_AutoBuildRoofAreaSetter_TryGenerateAreaNow
        {
            static bool Prefix()
            {
                if (RaiseTheRoofMod.settings != null)
                {
                    if (!RaiseTheRoofMod.settings.autoBuildRoof)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(AutoBuildRoofAreaSetter))]
        [HarmonyPatch("TryGenerateAreaOnImpassable")]
        static class Patch_AutoBuildRoofAreaSetter_TryGenerateAreaOnImpassable
        {
            static bool Prefix()
            {
                if (RaiseTheRoofMod.settings != null)
                {
                    if (!RaiseTheRoofMod.settings.autoBuildRoof)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(InfestationCellFinder))]
        [HarmonyPatch("GetScoreAt")]
        static class Patch_InfestationCellFinder_GetScoreAt
        {
            static bool CanSpawnAt(IntVec3 cell, Map map)
            {
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofSteel) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofSolar) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofTransparent) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofTransparentSolar) return false;
                return true;
            }
            static void Postfix(ref float __result, IntVec3 cell, Map map)
            {
                if (RaiseTheRoofMod.settings != null)
                {
                    if (!RaiseTheRoofMod.settings.allowInfestations)
                    {
                        if (!CanSpawnAt(cell, map))
                        {
                            __result = 0f;
                        }
                    }
                }
            }
        }
        [HarmonyPatch(typeof(DropCellFinder))]
        [HarmonyPatch("CanPhysicallyDropInto")]
        static class Patch_DropCellFinder_CanPhysicallyDropInto
        {
            static bool CanDropInto(IntVec3 cell, Map map)
            {
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofSteel) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofSolar) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofTransparent) return false;
                if (cell.GetRoof(map) == RoofDefOf.RTR_RoofTransparentSolar) return false;
                return true;
            }
            static void Postfix(ref bool __result, IntVec3 c, Map map)
            {
                if (!CanDropInto(c, map))
                {
                    __result = false;
                }
            }
        }
        [HarmonyPatch(typeof(SavedGameLoaderNow))]
        [HarmonyPatch("LoadGameFromSaveFileNow")]
        static class Patch_SavedGameLoaderNow_LoadGameFromSaveFileNow
        {
            static void Prefix()
            {
                RTRUtils.ApplySettings();
            }
        }
        [HarmonyPatch(typeof(GlowGrid))]
        [HarmonyPatch("GameGlowAt")]
        static class Patch_GlowGrid_GameGlowAt
        {
            static FieldInfo FI_map = typeof(GlowGrid).GetField("map", allFlags);
            static Map map(GlowGrid instance)
            {
                return (Map)FI_map.GetValue(instance);
            }
            static float GameGlowAt(GlowGrid instance, IntVec3 c, bool ignoreCavePlants = false)
            {
                float num = 0f;
                Map map = Patch_GlowGrid_GameGlowAt.map(instance);
                if (!map.roofGrid.Roofed(c) || map.roofGrid.RoofAt(c) == RoofDefOf.RTR_RoofTransparent || map.roofGrid.RoofAt(c) == RoofDefOf.RTR_RoofTransparentSolar)
                {
                    num = map.skyManager.CurSkyGlow;
                    if (num == 1f)
                    {
                        return num;
                    }
                }
                Color32 color = (ignoreCavePlants ? instance.glowGridNoCavePlants : instance.glowGrid)[map.cellIndices.CellToIndex(c)];
                if (color.a == 1)
                {
                    return 1f;
                }
                float b = (float)(color.r + color.g + color.b) / 3f / 255f * 3.6f;
                b = Mathf.Min(0.5f, b);
                return Mathf.Max(num, b);
            }
            static bool Prefix(ref GlowGrid __instance, ref float __result, ref IntVec3 c, bool ignoreCavePlants = false)
            {
                __result = GameGlowAt(__instance, c, ignoreCavePlants);
                return false;
            }
        }
        [HarmonyPatch(typeof(Area_BuildRoof))]
        [HarmonyPatch("Color", MethodType.Getter)]
        static class Patch_Area_BuildRoof_Color
        {
            static bool Prefix(ref Color __result)
            {
                __result = Color.green;
                return false;
            }
        }
        [HarmonyPatch(typeof(Area_NoRoof))]
        [HarmonyPatch("Color", MethodType.Getter)]
        static class Patch_Area_NoRoof_Color
        {
            static bool Prefix(ref Color __result)
            {
                __result = Color.red;
                return false;
            }
        }
        [HarmonyPatch(typeof(CompPowerPlantSolar))]
        [HarmonyPatch("RoofedPowerOutputFactor", MethodType.Getter)]
        static class Patch_CompPowerPlantSolar_RoofedPowerOutputFactor
        {
            static bool Prefix(CompPowerPlantSolar __instance, ref float __result)
            {
                int num = 0;
                int num2 = 0;
                foreach (IntVec3 current in __instance.parent.OccupiedRect())
                {
                    num++;
                    if (__instance.parent.Map.roofGrid.Roofed(current))
                    {
                        if (__instance.parent.Map.roofGrid.RoofAt(__instance.parent.Position) != RoofDefOf.RTR_RoofTransparent && __instance.parent.Map.roofGrid.RoofAt(__instance.parent.Position) != RoofDefOf.RTR_RoofTransparentSolar)
                        {
                            num2++;
                        }
                    }
                }
                __result = (num - num2) / num;
                return false;
            }
        }
        [HarmonyPatch(typeof(PowerNetGrid))]
        [HarmonyPatch("Notify_PowerNetDeleted")]
        static class Patch_PowerNetGrid_Notify_PowerNetDeleted
        {
            static FieldInfo FI_map = typeof(PowerNetGrid).GetField("map", allFlags);
            static FieldInfo FI_netGrid = typeof(PowerNetGrid).GetField("netGrid", allFlags);
            static FieldInfo FI_powerNetCells = typeof(PowerNetGrid).GetField("powerNetCells", allFlags);
            static Map map(PowerNetGrid instance)
            {
                return (Map)FI_map.GetValue(instance);
            }
            static PowerNet[] netGrid(PowerNetGrid instance)
            {
                return (PowerNet[])FI_netGrid.GetValue(instance);
            }
            static Dictionary<PowerNet, List<IntVec3>> powerNetCells(PowerNetGrid instance)
            {
                return (Dictionary<PowerNet, List<IntVec3>>)FI_powerNetCells.GetValue(instance);
            }
            static bool Prefix(PowerNetGrid __instance, PowerNet deadNet)
            {
                List<IntVec3> list;
                bool foundSolarPowerCell = false;
                if (!powerNetCells(__instance).TryGetValue(deadNet, out list))
                {
                    Log.Warning("Net " + deadNet + " does not exist in PowerNetGrid's dictionary.", false);
                    return false;
                }
                for (int i = 0; i < list.Count; i++)
                {
                    int num = map(__instance).cellIndices.CellToIndex(list[i]);
                    if (map(__instance).roofGrid.RoofAt(num) == RoofDefOf.RTR_RoofSolar || map(__instance).roofGrid.RoofAt(num) == RoofDefOf.RTR_RoofTransparentSolar)
                    {
                        foundSolarPowerCell = true;
                    }
                    if (netGrid(__instance)[num] == deadNet)
                    {
                        netGrid(__instance)[num] = null;
                    }
                    else if (!foundSolarPowerCell)
                    {
                        Log.Warning("Multiple nets on the same cell " + list[i] + ". This is probably a result of an earlier error.", false);
                    }
                }
                powerNetCells(__instance).Remove(deadNet);
                return false;
            }
        }
        [HarmonyPatch(typeof(PowerNetGrid))]
        [HarmonyPatch("Notify_PowerNetCreated")]
        static class Patch_PowerNetGrid_Notify_PowerNetCreated
        {
            static FieldInfo FI_map = typeof(PowerNetGrid).GetField("map", allFlags);
            static FieldInfo FI_netGrid = typeof(PowerNetGrid).GetField("netGrid", allFlags);
            static FieldInfo FI_powerNetCells = typeof(PowerNetGrid).GetField("powerNetCells", allFlags);
            static Map map(PowerNetGrid instance)
            {
                return (Map)FI_map.GetValue(instance);
            }
            static PowerNet[] netGrid(PowerNetGrid instance)
            {
                return (PowerNet[])FI_netGrid.GetValue(instance);
            }
            static Dictionary<PowerNet, List<IntVec3>> powerNetCells(PowerNetGrid instance)
            {
                return (Dictionary<PowerNet, List<IntVec3>>)FI_powerNetCells.GetValue(instance);
            }
            static bool Prefix(PowerNetGrid __instance, PowerNet newNet)
            {
                if (powerNetCells(__instance).ContainsKey(newNet))
                {
                    Log.Warning("Net " + newNet + " is already registered in PowerNetGrid.", false);
                    powerNetCells(__instance).Remove(newNet);
                }
                List<IntVec3> list = new List<IntVec3>();
                powerNetCells(__instance).Add(newNet, list);
                bool foundSolarPowerCell = false;
                for (int i = 0; i < newNet.transmitters.Count; i++)
                {
                    CellRect cellRect = newNet.transmitters[i].parent.OccupiedRect();
                    for (int j = cellRect.minZ; j <= cellRect.maxZ; j++)
                    {
                        for (int k = cellRect.minX; k <= cellRect.maxX; k++)
                        {
                            int num = map(__instance).cellIndices.CellToIndex(k, j);
                            if (map(__instance).roofGrid.RoofAt(num) == RoofDefOf.RTR_RoofSolar || map(__instance).roofGrid.RoofAt(num) == RoofDefOf.RTR_RoofTransparentSolar)
                            {
                                foundSolarPowerCell = true;
                            }
                            if (netGrid(__instance)[num] != null && !foundSolarPowerCell)
                            {
                                Log.Warning(string.Concat(new object[]
                                {
                    "Two power nets on the same cell (",
                    k,
                    ", ",
                    j,
                    "). First transmitters: ",
                    newNet.transmitters[0].parent.LabelCap,
                    " and ",
                    netGrid(__instance)[num].transmitters.NullOrEmpty() ? "[none]" : netGrid(__instance)[num].transmitters[0].parent.LabelCap,
                    "."
                                }), false);
                            }
                            netGrid(__instance)[num] = newNet;
                            list.Add(new IntVec3(k, 0, j));
                        }
                    }
                }
                return false;
            }
        }
        [HarmonyPatch(typeof(Log))]
        [HarmonyPatch("Warning")]
        static class Patch_Log_Warning
        {
            static bool Prefix(ref string text)
            {
                if (text.Contains("There can't be two transmitters on the same cell.") || text.Contains("RTR_"))
                {
                    return false;
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(Verse.RoofCollapseCellsFinder))]
        [HarmonyPatch("Notify_RoofHolderDespawned")]
        static class Patch_RoofCollapseCellsFinder_Notify_RoofHolderDespawned
        {
            static bool Prefix(Thing t, Map map)
            {
                if (Current.ProgramState == ProgramState.Playing)
                {
                    if (t.def == RimWorld.ThingDefOf.CollapsedRocks)
                    {
                        Thing thing = RTRUtils.RemoveRoofExists(t.Position, map);
                        if (thing != null)
                        {
                            thing.Kill();
                            map.roofGrid.SetRoof(t.Position, null);
                        }
                    }
                    RoofCollapseCellsFinder.ProcessRoofHolderDespawned(t.OccupiedRect(), t.Position, map, true, false);
                    return false;
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(Tornado))]
        [HarmonyPatch("DestroyRoofs")]
        static class Patch_Tornado_DestroyRoofs
        {
            static FieldInfo FI_removedRoofsTmp = typeof(Tornado).GetField("removedRoofsTmp", allFlags);
            static MethodInfo MI_CellImmuneToDamage = typeof(Tornado).GetMethod("CellImmuneToDamage", allFlags);
            static List<IntVec3> removedRoofsTmp(Tornado instance)
            {
                return (List<IntVec3>)FI_removedRoofsTmp.GetValue(instance);
            }
            static bool CellImmuneToDamage(Tornado instance, IntVec3 c)
            {
                return (bool)MI_CellImmuneToDamage.Invoke(instance, new object[] { c });
            }
            static bool Prefix(Tornado __instance)
            {
                removedRoofsTmp(__instance).Clear();
                foreach (IntVec3 item in from x in GenRadial.RadialCellsAround(__instance.Position, 4.2f, useCenter: true)
                                         where x.InBounds(__instance.Map)
                                         select x)
                {
                    if (!CellImmuneToDamage(__instance, item) && item.Roofed(__instance.Map))
                    {
                        RoofDef roof = item.GetRoof(__instance.Map);
                        if (!roof.isThickRoof && !roof.isNatural)
                        {
                            RoofCollapserImmediate.DropRoofInCells(item, __instance.Map);
                            removedRoofsTmp(__instance).Add(item);
                        }
                    }
                }
                if (removedRoofsTmp(__instance).Count > 0)
                {
                    RoofCollapseCellsFinder.CheckCollapseFlyingRoofs(removedRoofsTmp(__instance), __instance.Map, removalMode: true);
                }
                return false;
            }
        }
        [HarmonyPatch(typeof(JobDriver_RemoveRoof))]
        [HarmonyPatch("DoEffect")]
        static class Patch_JobDriver_RemoveRoof_DoEffect
        {
            static FieldInfo FI_removedRoofs = typeof(JobDriver_RemoveRoof).GetField("removedRoofs", allFlags);
            static PropertyInfo PI_Cell = typeof(JobDriver_AffectRoof).GetProperty("Cell", allFlags);
            static PropertyInfo PI_Map = typeof(JobDriver).GetProperty("Map", allFlags);
            static List<IntVec3> removedRoofs(JobDriver_RemoveRoof instance)
            {
                return (List<IntVec3>)FI_removedRoofs.GetValue(instance);
            }
            static IntVec3 Cell(JobDriver_AffectRoof instance)
            {
                return (IntVec3)PI_Cell.GetValue(instance, null);
            }
            static Map Map(JobDriver instance)
            {
                return (Map)PI_Map.GetValue(instance, null);
            }
            static bool Prefix(JobDriver_RemoveRoof __instance)
            {
                removedRoofs(__instance).Clear();
                Map(__instance as JobDriver).roofGrid.SetRoof(Cell(__instance), null);
                removedRoofs(__instance).Add(Cell(__instance as JobDriver_AffectRoof));
                RoofCollapseCellsFinder.CheckCollapseFlyingRoofs(removedRoofs(__instance), Map(__instance as JobDriver), true, false);
                removedRoofs(__instance).Clear();
                return false;
            }
        }
        [HarmonyPatch(typeof(DebugToolsGeneral))]
        [HarmonyPatch("Kill")]
        static class Patch_DebugToolsGeneral_Kill
        {
            static bool Prefix()
            {
                foreach (Thing item in Find.CurrentMap.thingGrid.ThingsAt(UI.MouseCell()).ToList())
                {
                    if (item.def != ThingDefOf.RTR_SolarRoofPowerCell && item.def != ThingDefOf.RTR_TransparentSolarRoofPowerCell)
                    {
                        item.Kill();
                    }
                }
                return false;
            }
        }
        [HarmonyPatch(typeof(GenConstruct))]
        [HarmonyPatch("CanConstruct")]
        static class Patch_GenConstruct_CanConstruct
        {
            public static bool CanConstruct(Building b)
            {
                if (RTRUtils.RoofHolderBuildingExists(b.Position, b.Map))
                {
                    return true;
                }
                int num = 0;
                for (int i = 0; i < 4; i++)
                {
                    IntVec3 c = b.Position + GenAdj.CardinalDirections[i];
                    if (c.InBounds(b.Map) && b.Map.roofGrid.Roofed(c))
                    {
                        num++;
                    }
                }
                if (num == 0)
                {
                    return false;
                }
                return true;
            }
            static bool Prefix(ref bool __result, Thing t)
            {
                Building b = t as Building;
                if (b != null && RTRUtils.RoofFrameOrBlueprintExists(b))
                {
                    __result = CanConstruct(b);
                    return false;
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(Thing))]
        [HarmonyPatch("LabelCap", MethodType.Getter)]
        static class Patch_Thing_LabelCap
        {
            static bool Prefix(ref string __result, Thing __instance)
            {
                if (__instance != null)
                {
                    if (__instance.def == ThingDefOf.RTR_SolarRoofPowerCell || __instance.def == ThingDefOf.RTR_TransparentSolarRoofPowerCell)
                    {
                        CompPowerCell comp = __instance.TryGetComp<CompPowerCell>();
                        if (comp != null)
                        {
                            if (!__instance.Label.NullOrEmpty())
                            {
                                string labelCap = __instance.Label.CapitalizeFirst(__instance.def) + " (" + (int)comp.PowerOutput + " W)";
                                __result = labelCap;
                                return false;
                            }
                        }
                    }
                }              
                return true;
            }
        }
        [HarmonyPatch(typeof(Widgets), "Label", new Type[] { typeof(Rect), typeof(string) })]
        static class Patch_Widgets_Label
        {
            static bool Prefix(string label)
            {
                if (!label.NullOrEmpty())
                {
                    if (label.Equals("Constructed solar roof") || label.Equals("Constructed transparent solar roof"))
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        [HarmonyPatch(typeof(JobDriver_HaulToContainer))]
        [HarmonyPatch("TryMakePreToilReservations")]
        static class Patch_JobDriver_HaulToContainer_TryMakePreToilReservations
        {
            static bool Prefix(ref bool __result, JobDriver_HaulToContainer __instance)
            {
                JobDriver jobDriver = __instance as JobDriver;
                if (jobDriver != null)
                {
                    Job job = jobDriver.job;
                    if (job != null)
                    {
                        LocalTargetInfo target = job.GetTarget(TargetIndex.B);
                        if (target != null && target.Thing != null)
                        {
                            if (target.Thing.def.defName.Contains("RTR_") && !jobDriver.pawn.CanReserve(target, 1, -1, null))
                            {
                                __result = false;
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
        }
    }
}