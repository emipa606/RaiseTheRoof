using RimWorld;
using Verse;

namespace RaiseTheRoof
{
    [DefOf]
    public static class ResearchProjectDefOf
    {
        public static ResearchProjectDef RTR_OverheadMountainRemoval;
        public static ResearchProjectDef RTR_TransparentRoofing;
        public static ResearchProjectDef RTR_SolarRoofing;
        public static ResearchProjectDef RTR_TransparentSolarRoofing;
    }
}
